import React from 'react';

export function NotFound() {
  return (
    <div>NotFound</div>
  );
}
